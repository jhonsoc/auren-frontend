'use client';

import { useEffect, useState } from 'react';
import EditarEmpresaModal from './EditarEmpresaModal';
import { Pencil, Trash2 } from 'lucide-react';

interface Empresa {
  id: string;
  nit: string;
  razonSocial: string;
  direccion: string;
  telefono: string;
}

export default function ListaEmpresas() {
  const [empresas, setEmpresas] = useState<Empresa[]>([]);
  const [empresaEditando, setEmpresaEditando] = useState<Empresa | null>(null);
  const [filtroNIT, setFiltroNIT] = useState('');
  const [filtroNombre, setFiltroNombre] = useState('');

  const cargarEmpresas = () => {
    const token = localStorage.getItem('token');
    fetch(`${process.env.NEXT_PUBLIC_API_URL}/empresas`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then((res) => res.json())
      .then(setEmpresas)
      .catch(() => {});
  };

  useEffect(() => {
    cargarEmpresas();
  }, []);

  const eliminarEmpresa = async (id: string) => {
    if (!confirm('¿Deseas eliminar esta empresa?')) return;

    const token = localStorage.getItem('token');
    await fetch(`${process.env.NEXT_PUBLIC_API_URL}/empresas/${id}`, {
      method: 'DELETE',
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    cargarEmpresas();
  };

  const empresasFiltradas = empresas.filter((empresa) => {
    const nitMatch = empresa.nit.toLowerCase().includes(filtroNIT.toLowerCase());
    const nombreMatch = empresa.razonSocial.toLowerCase().includes(filtroNombre.toLowerCase());
    return nitMatch && nombreMatch;
  });

  return (
    <div className="p-6 overflow-x-auto">
      <h2 className="text-2xl font-bold mb-4 text-blue-800">Empresas Registradas</h2>

      <div className="flex gap-4 mb-4">
        <input
          type="text"
          placeholder="Buscar por NIT"
          value={filtroNIT}
          onChange={(e) => setFiltroNIT(e.target.value)}
          className="border px-3 py-2 rounded w-1/3 text-black"
        />
        <input
          type="text"
          placeholder="Buscar por razón social"
          value={filtroNombre}
          onChange={(e) => setFiltroNombre(e.target.value)}
          className="border px-3 py-2 rounded w-2/3 text-black"
        />
      </div>

      <table className="w-full text-sm text-left border rounded overflow-hidden shadow bg-white">
        <thead className="bg-blue-100 text-blue-900">
          <tr>
            <th className="px-4 py-2">NIT</th>
            <th className="px-4 py-2">Razón Social</th>
            <th className="px-4 py-2">Dirección</th>
            <th className="px-4 py-2">Teléfono</th>
            <th className="px-4 py-2">Acciones</th>
          </tr>
        </thead>
        <tbody className="text-black">
          {empresasFiltradas.length > 0 ? (
            empresasFiltradas.map((e) => (
              <tr key={e.id} className="border-t hover:bg-blue-50 transition group">
                <td className="px-4 py-2">{e.nit}</td>
                <td className="px-4 py-2">{e.razonSocial}</td>
                <td className="px-4 py-2">{e.direccion}</td>
                <td className="px-4 py-2">{e.telefono}</td>
                <td className="px-4 py-2">
                  <div className="invisible group-hover:visible flex gap-2">
                    <button
                      onClick={() => setEmpresaEditando(e)}
                      className="flex items-center gap-1 text-black hover:text-blue-600 transition"
                      title="Editar"
                    >
                      <Pencil size={16} />
                    </button>
                    <button
                      onClick={() => eliminarEmpresa(e.id)}
                      className="flex items-center gap-1 text-black hover:text-red-600 transition"
                      title="Eliminar"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan={5} className="text-center py-4 text-gray-500">
                No hay empresas registradas.
              </td>
            </tr>
          )}
        </tbody>
      </table>

      {empresaEditando && (
        <EditarEmpresaModal
          empresa={empresaEditando}
          onClose={() => setEmpresaEditando(null)}
          onUpdate={cargarEmpresas}
        />
      )}
    </div>
  );
}
