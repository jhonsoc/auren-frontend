'use client';

import ConsultarUsuariosEmpresa from './ConsultarUsuariosEmpresa';

export default function UsuarioEmpresaPage() {
  return <ConsultarUsuariosEmpresa />;
}
