import RegistrarUsuarioEmpresa from '../RegistrarUsuarioEmpresa';

export default function RegistrarUsuarioPage() {
  return <RegistrarUsuarioEmpresa />;
}